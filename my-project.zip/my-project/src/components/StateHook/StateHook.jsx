import React, { useState } from 'react'

function StateHook({count,changeCount}) {

    const [userName, setuserName] = useState('Hinata')

  const changeUserName =()=>{
    if(userName === 'Hinata') {
      setuserName("Sakura")
    }else{
       setuserName("Hinata")
    }
    
  }
  
  const increment =()=>{
    changeCount(count+1);
  }

  return (
    <div>
      <h1>State in React</h1>
      <hr/>
      <h1>Welcome {userName}</h1>
      <br/>
      <button onClick={changeUserName}>change name</button>
      <hr/>
      <h1> <strong> {count}</strong></h1>
      <button onClick={increment}>Increment</button>
    </div>
  )
}

export default StateHook
