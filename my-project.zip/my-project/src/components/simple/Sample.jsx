import React from 'react'

function Sample({uName,role,count}) {

 let username = 'Hinata';

    // function btnClick() {
    //     console.log("btn is clicked...");
        
    // }

    //callbackfunction
    const btnClick=()=>{
     console.log("btn function is clicked");
     
    }

  return (
    <div>
      <h1>We are from sample page</h1>
      <h1>welcome {username} </h1>
      {/* <h1>welcome {props.uName} </h1> */}
      <h1>welcome --{uName} {role} count={count}</h1>
      <button onClick={btnClick}>Click</button>
    </div>
  )
}

export default Sample
