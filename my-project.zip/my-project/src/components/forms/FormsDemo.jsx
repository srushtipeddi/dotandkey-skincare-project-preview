import React, { useState } from 'react'

function FormsDemo() {
  
    const [email, setemail] = useState('abc@gmail.com')
    const [password, setpassword] = useState('123')

    const changeEmail=(e)=>{
    //  console.log(e.target.name);
    //  console.log(e.target.value);

     setemail(e.target.value);
    }

    const changePassword=(e)=>{
    //  console.log(e.target.name);
    //  console.log(e.target.value);

     setpassword(e.target.value);
    }

    const submitForm =()=>{
    console.log("form Submitted....");
    console.log(email);
    console.log(password);
    
    
    }
  return (
    <div className='container'>
      <h1> Forms</h1>
       <div className="container">
        <div className="login-container">
            <h2 className="text-center mb-4">Login</h2>
            <form>
                <div className="mb-3">
                    <label htmlFor="loginEmail" className="form-label">Email address</label>
                    {/* <h1>{email}</h1> */}
                    <input type="email" name='email' value={email} onChange={changeEmail} className="form-control" id="loginEmail" placeholder="name@example.com"/>
                </div>
                
                <div className="mb-3">
                    <label htmlFor="loginPassword" className="form-label">Password</label>
                    <input type="password" name="password" value={password} onChange={changePassword}className="form-control" id="loginPassword" placeholder="Enter your password"/>
                </div>
                
                <div className="mb-3 form-check">
                    <input type="checkbox" className="form-check-input" id="rememberMe"/>
                    <label className="form-check-label" htmlFor="rememberMe">Remember me</label>
                </div>
                
                <button type="submit"  onClick={submitForm} className="btn btn-primary w-100 mb-3">Login</button>
                
                
            </form>
        </div>
    </div>
    </div>
  )
}

export default FormsDemo
